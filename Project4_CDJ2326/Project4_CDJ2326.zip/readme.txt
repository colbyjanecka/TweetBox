/* EE422C Assignment #4 submission by
 * Colby Janecka
 * CDJ2326
 */

Compile: 

javac -cp lib/annotations-13.0.jar:lib/jackson-annotations-2.10.0.jar:lib/jackson-core-2.10.0.jar:lib/jackson-databind-2.10.0.jar:lib/kotlin-stdlib-1.3.50.jar:lib/kotlin-stdlib-common-1.3.50.jar:lib/okhttp-4.2.1.jar:lib/okio-2.2.2.jar src/assignment4/*.java -d bin


Run:

java -cp lib/annotations-13.0.jar:lib/jackson-annotations-2.10.0.jar:lib/jackson-core-2.10.0.jar:lib/jackson-databind-2.10.0.jar:lib/kotlin-stdlib-1.3.50.jar:lib/kotlin-stdlib-common-1.3.50.jar:lib/okhttp-4.2.1.jar:lib/okio-2.2.2.jar:bin assignment4.Main

